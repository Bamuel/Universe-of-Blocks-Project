var pepe21 = 1;
switch(pepe21)
	{
		case 0:
		alert('a = 0');
		break;
		case 1:
		alert('a = 1');
		break;
		default:
		alert('a = ?');
		break;
	}