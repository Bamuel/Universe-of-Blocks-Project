#  **Universe of Blocks**
  The game can be played on
  -[uob.bamuel.com](http://uob.bamuel.com/index.html)
  -[universeofblocksbeta.16mb.com](http://universeofblocksbeta.16mb.com/)
## Todo
- [x] Clean up source for easier (allocate folders for css,font,images,old files, etc...)
- [ ] Remove *open new tab 
- [x] Redesign textures
- [ ] Add Steve and other characters (skins are not necessary)
- [x] Make an informational page, better. (eg. Twitter)
- [ ] Make a donation page
- [ ] Add more maps
- [x] *80% done* Add all blocks
- [ ] Save map by their ip *php
- [x] Fix the spaces in creative sections
- [ ] Implement the secondary panel

### Credits 
- Edgar
- AveryDee
- Bamuel (Samuel)
